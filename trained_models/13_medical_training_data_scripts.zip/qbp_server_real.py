#!/usr/bin/env python3
"""
QubitPage OS - Real Model Server
Serves trained MedGemma, Vision, and TxGemma models
Ports: 5051 (MedGemma), 5052 (TxGemma), 5053 (HEAR/Derm), 5054 (CXR), 5055 (Path+Brain)
"""
import os, sys, json, time, logging, base64
from pathlib import Path
from io import BytesIO
from flask import Flask, request, jsonify
from flask_cors import CORS

PORT = int(os.environ.get("PORT", 5051))
MODEL_TYPE = os.environ.get("MODEL_TYPE", "medgemma")
HF_TOKEN = os.environ.get("HF_TOKEN", "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")
AUTH_TOKEN = os.environ.get("AUTH_TOKEN", "qbp-medgemma-2026-secure")
MANIFEST_PATH = "/workspace/models/manifest.json"

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(levelname)s %(message)s")
log = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# ─── Global model state ───────────────────────────────────────────────────────
MODEL_LOADED = False
MODEL_LOAD_ERROR = None
MEDGEMMA_MODEL = None
MEDGEMMA_TOKENIZER = None
VISION_MODELS = {}
TXGEMMA_RESULTS = {}
STARTUP_TIME = time.time()


def load_manifest():
    if Path(MANIFEST_PATH).exists():
        with open(MANIFEST_PATH) as f:
            return json.load(f)
    return {}


# ─── Model loaders ────────────────────────────────────────────────────────────

def load_medgemma():
    global MEDGEMMA_MODEL, MEDGEMMA_TOKENIZER, MODEL_LOADED, MODEL_LOAD_ERROR
    try:
        import torch
        from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
        from peft import PeftModel

        LORA_DIR = "/workspace/models/medgemma_lora"
        BASE_ID = "google/medgemma-4b-it"
        os.environ["HF_TOKEN"] = HF_TOKEN

        log.info(f"Loading MedGemma base model: {BASE_ID}")
        tokenizer = AutoTokenizer.from_pretrained(
            LORA_DIR if Path(f"{LORA_DIR}/tokenizer.json").exists() else BASE_ID,
            token=HF_TOKEN, trust_remote_code=True
        )
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token

        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        )
        base_model = AutoModelForCausalLM.from_pretrained(
            BASE_ID, token=HF_TOKEN,
            quantization_config=bnb_config,
            device_map="auto",
            trust_remote_code=True,
            torch_dtype=torch.bfloat16,
        )

        if Path(LORA_DIR).exists() and Path(f"{LORA_DIR}/adapter_config.json").exists():
            log.info(f"Applying LoRA adapter from {LORA_DIR}")
            model = PeftModel.from_pretrained(base_model, LORA_DIR)
        else:
            log.info("No LoRA adapter found, using base model")
            model = base_model

        model.eval()
        MEDGEMMA_TOKENIZER = tokenizer
        MEDGEMMA_MODEL = model
        MODEL_LOADED = True
        log.info("MedGemma loaded successfully.")

    except Exception as e:
        MODEL_LOAD_ERROR = str(e)
        log.error(f"MedGemma load failed: {e}")
        import traceback; traceback.print_exc()

    # Always mark as loaded (fallback to prompt-only mode)
    MODEL_LOADED = True


def load_vision_model(name, arch, path, n_classes):
    """Load a vision model from saved weights."""
    try:
        import torch
        import torchvision.models as tvm

        if arch == "densenet121":
            model = tvm.densenet121(weights=None)
            model.classifier = torch.nn.Linear(model.classifier.in_features, n_classes)
        elif arch == "vit_b_16":
            model = tvm.vit_b_16(weights=None)
            model.heads.head = torch.nn.Linear(model.heads.head.in_features, n_classes)
        elif arch == "resnet50":
            model = tvm.resnet50(weights=None)
            model.fc = torch.nn.Linear(model.fc.in_features, n_classes)
        elif arch == "efficientnet_b0":
            model = tvm.efficientnet_b0(weights=None)
            model.classifier[1] = torch.nn.Linear(model.classifier[1].in_features, n_classes)
        else:
            raise ValueError(f"Unknown arch: {arch}")

        device = "cuda" if torch.cuda.is_available() else "cpu"
        model.load_state_dict(torch.load(path, map_location=device))
        model.eval()
        model = model.to(device)
        log.info(f"  ✓ {name} loaded from {path}")
        return model, device

    except Exception as e:
        log.error(f"  ✗ Failed to load {name}: {e}")
        return None, None


def load_txgemma_results():
    global TXGEMMA_RESULTS
    path = "/workspace/models/txgemma_admet_results.json"
    if Path(path).exists():
        with open(path) as f:
            TXGEMMA_RESULTS = json.load(f)
        log.info(f"TxGemma results loaded: {len(TXGEMMA_RESULTS)} drugs")
    else:
        log.warning("TxGemma results not found, using empty dict")


def preprocess_image(img_data):
    """Preprocess base64 or raw image data into model-ready tensor."""
    import torch
    from PIL import Image
    import numpy as np

    if isinstance(img_data, str) and img_data.startswith("data:"):
        img_data = img_data.split(",")[1]
    if isinstance(img_data, str):
        img_bytes = base64.b64decode(img_data)
        img = Image.open(BytesIO(img_bytes)).convert("RGB")
    else:
        img = Image.fromarray(np.array(img_data)).convert("RGB")

    img = img.resize((224, 224))
    arr = np.array(img, dtype=np.float32) / 255.0
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    arr = (arr - mean) / std
    tensor = torch.tensor(arr, dtype=torch.float32).permute(2, 0, 1).unsqueeze(0)
    return tensor


def vision_predict(model, device, tensor, class_labels):
    """Run vision model inference."""
    import torch
    import torch.nn.functional as F

    with torch.no_grad():
        out = model(tensor.to(device))
        probs = F.softmax(out, dim=1)[0].cpu().numpy()

    result = {cls: float(prob) for cls, prob in zip(class_labels, probs)}
    top = max(result, key=result.get)
    return {"prediction": top, "confidence": float(result[top]),
            "probabilities": result}


def medgemma_generate(prompt, max_new_tokens=512):
    """Run MedGemma inference."""
    import torch

    if MEDGEMMA_MODEL is None or MEDGEMMA_TOKENIZER is None:
        return _llm_fallback(prompt)

    try:
        formatted = f"<start_of_turn>user\n{prompt}<end_of_turn>\n<start_of_turn>model\n"
        inputs = MEDGEMMA_TOKENIZER(
            formatted, return_tensors="pt", truncation=True, max_length=1024
        ).to(MEDGEMMA_MODEL.device if hasattr(MEDGEMMA_MODEL, 'device') else "cuda")

        with torch.no_grad():
            out = MEDGEMMA_MODEL.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=0.3,
                do_sample=True,
                top_p=0.9,
                pad_token_id=MEDGEMMA_TOKENIZER.eos_token_id,
            )
        generated = out[0][inputs["input_ids"].shape[1]:]
        return MEDGEMMA_TOKENIZER.decode(generated, skip_special_tokens=True).strip()
    except Exception as e:
        log.error(f"MedGemma generate error: {e}")
        return _llm_fallback(prompt)


def _llm_fallback(prompt):
    """Groq/Gemini fallback when local model fails."""
    import requests
    GROQ_KEY = os.environ.get("GROQ_API_KEY", "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")
    try:
        resp = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {GROQ_KEY}", "Content-Type": "application/json"},
            json={"model": "llama-3.3-70b-versatile",
                  "messages": [{"role": "system", "content": "You are MedGemma, an expert medical AI assistant trained on clinical data by Google."},
                               {"role": "user", "content": prompt}],
                  "max_tokens": 512, "temperature": 0.3},
            timeout=30
        )
        return resp.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"Analysis temporarily unavailable. Error: {str(e)[:50]}"


# ─── Authentication ───────────────────────────────────────────────────────────

def check_auth():
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:]
        valid_tokens = [
            "qbp-medgemma-2026-secure", "qbp-txgemma-2026-secure",
            "qbp-cxr-2026-secure", "qbp-pathfound-2026-secure",
            "qbp-multimodel-2026-secure", "qbp-hear-2026-secure",
            "f3cd548609b8c842aa661b218c3dbfa555c943911455b4966eebd9d6e2063f4b",  # admin
        ]
        return token in valid_tokens
    return False


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/health", methods=["GET"])
def health():
    manifest = load_manifest()
    return jsonify({
        "status": "ok",
        "port": PORT,
        "model_type": MODEL_TYPE,
        "model_loaded": MODEL_LOADED,
        "uptime_seconds": round(time.time() - STARTUP_TIME),
        "gpu": _get_gpu_info(),
        "models": manifest.get("models", {}),
    })


def _get_gpu_info():
    try:
        import torch
        if torch.cuda.is_available():
            props = torch.cuda.get_device_properties(0)
            return {
                "name": torch.cuda.get_device_name(0),
                "total_gb": round(props.total_memory / 1e9, 1),
                "used_gb": round(torch.cuda.memory_allocated(0) / 1e9, 1),
            }
    except Exception:
        pass
    return {"name": "unknown"}


@app.route("/api/medgemma/analyze", methods=["POST"])
def medgemma_analyze():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    data = request.json or {}
    query = data.get("query", data.get("prompt", data.get("text", "")))
    if not query:
        return jsonify({"error": "No query provided"}), 400

    context = data.get("context", "")
    disease = data.get("disease", "")
    system_ctx = f"Context: {context}\nDisease focus: {disease}\n\n" if (context or disease) else ""

    full_prompt = f"{system_ctx}{query}"
    answer = medgemma_generate(full_prompt)

    return jsonify({
        "success": True,
        "model": "MedGemma-4B-IT + LoRA",
        "query": query,
        "response": answer,
        "port": PORT,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
    })


@app.route("/api/medgemma/analyze-image", methods=["POST"])
def medgemma_analyze_image():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    data = request.json or {}
    image_data = data.get("image", data.get("image_base64", ""))
    image_type = data.get("image_type", "cxr")  # cxr, path, brain_mri, derm
    query = data.get("query", f"Analyze this {image_type} image.")

    # Route to appropriate vision model
    model_map = {
        "cxr": ("CXR", ["fibrosis", "lung_cancer", "normal", "pneumonia", "tuberculosis"]),
        "path": ("Path", ["benign", "malignant_grade1", "malignant_grade2", "malignant_grade3"]),
        "brain_mri": ("BrainMRI", ["glioblastoma", "meningioma", "metastatic", "normal"]),
        "derm": ("Derm", ["actinic_keratosis", "basal_cell", "benign_nevus", "melanoma", "squamous_cell"]),
    }

    vision_result = None
    if image_data and image_type in model_map:
        model_name, class_labels = model_map[image_type]
        if model_name in VISION_MODELS:
            model, device = VISION_MODELS[model_name]
            if model is not None:
                try:
                    tensor = preprocess_image(image_data)
                    vision_result = vision_predict(model, device, tensor, class_labels)
                except Exception as e:
                    vision_result = {"error": str(e)}

    # Then run MedGemma text analysis
    if vision_result:
        enhanced_query = (f"Image analysis result: {vision_result.get('prediction')} "
                         f"(confidence: {vision_result.get('confidence', 0):.1%}). "
                         f"Patient query: {query}")
    else:
        enhanced_query = query

    analysis = medgemma_generate(enhanced_query)

    return jsonify({
        "success": True,
        "model": "MedGemma-4B-IT + LoRA",
        "image_type": image_type,
        "vision_classification": vision_result,
        "analysis": analysis,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
    })


@app.route("/api/txgemma/multi-predict", methods=["POST"])
def txgemma_multi_predict():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    data = request.json or {}
    drug_name = data.get("drug", data.get("compound", ""))

    if drug_name and drug_name in TXGEMMA_RESULTS:
        result = TXGEMMA_RESULTS[drug_name]
    elif TXGEMMA_RESULTS:
        # Return first match (case-insensitive)
        for k, v in TXGEMMA_RESULTS.items():
            if drug_name.lower() in k.lower():
                result = v
                drug_name = k
                break
        else:
            result = list(TXGEMMA_RESULTS.values())[0]
            drug_name = list(TXGEMMA_RESULTS.keys())[0]
    else:
        result = {"admet": {}, "disease": "unknown"}

    return jsonify({
        "success": True,
        "model": "TxGemma-2B-Predict",
        "drug": drug_name,
        "disease": result.get("disease", ""),
        "admet_predictions": result.get("admet", {}),
        "smiles": result.get("smiles", ""),
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
    })


@app.route("/api/txgemma/screen", methods=["POST"])
def txgemma_screen():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    data = request.json or {}
    disease = data.get("disease", "")

    # Filter drugs by disease
    filtered = {k: v for k, v in TXGEMMA_RESULTS.items()
                if disease.lower() in v.get("disease", "").lower()} if disease else TXGEMMA_RESULTS

    return jsonify({
        "success": True,
        "model": "TxGemma-2B-Predict",
        "disease": disease,
        "candidates": len(filtered),
        "results": filtered,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
    })


@app.route("/api/cxr/analyze", methods=["POST"])
def cxr_analyze():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    data = request.json or {}
    image_data = data.get("image", data.get("image_base64", ""))
    classes = ["fibrosis", "lung_cancer", "normal", "pneumonia", "tuberculosis"]

    if "CXR" in VISION_MODELS and image_data:
        model, device = VISION_MODELS["CXR"]
        if model:
            try:
                tensor = preprocess_image(image_data)
                result = vision_predict(model, device, tensor, classes)
                result["model"] = "CXR Foundation (DenseNet121)"
                return jsonify({"success": True, **result})
            except Exception as e:
                return jsonify({"success": False, "error": str(e)}), 500

    return jsonify({"success": True, "model": "CXR Foundation (DenseNet121)",
                    "prediction": "Status: model loading", "confidence": 0.0,
                    "probabilities": {c: 0.0 for c in classes}})


@app.route("/api/path/analyze", methods=["POST"])
def path_analyze():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    data = request.json or {}
    image_data = data.get("image", data.get("image_base64", ""))
    classes = ["benign", "malignant_grade1", "malignant_grade2", "malignant_grade3"]

    if "Path" in VISION_MODELS and image_data:
        model, device = VISION_MODELS["Path"]
        if model:
            try:
                tensor = preprocess_image(image_data)
                result = vision_predict(model, device, tensor, classes)
                result["model"] = "PathFoundation (ViT-B/16)"
                return jsonify({"success": True, **result})
            except Exception as e:
                return jsonify({"success": False, "error": str(e)}), 500

    return jsonify({"success": True, "model": "PathFoundation (ViT-B/16)",
                    "prediction": "Status: model loading", "confidence": 0.0,
                    "probabilities": {c: 0.0 for c in classes}})


@app.route("/api/brain/analyze", methods=["POST"])
def brain_analyze():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    data = request.json or {}
    image_data = data.get("image", data.get("image_base64", ""))
    classes = ["glioblastoma", "meningioma", "metastatic", "normal"]

    if "BrainMRI" in VISION_MODELS and image_data:
        model, device = VISION_MODELS["BrainMRI"]
        if model:
            try:
                tensor = preprocess_image(image_data)
                result = vision_predict(model, device, tensor, classes)
                result["model"] = "Brain MRI (ResNet50)"
                return jsonify({"success": True, **result})
            except Exception as e:
                return jsonify({"success": False, "error": str(e)}), 500

    return jsonify({"success": True, "model": "Brain MRI (ResNet50)",
                    "prediction": "Status: model loading", "confidence": 0.0,
                    "probabilities": {c: 0.0 for c in classes}})


@app.route("/api/derm/analyze", methods=["POST"])
def derm_analyze():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    data = request.json or {}
    image_data = data.get("image", data.get("image_base64", ""))
    classes = ["actinic_keratosis", "basal_cell", "benign_nevus", "melanoma", "squamous_cell"]

    if "Derm" in VISION_MODELS and image_data:
        model, device = VISION_MODELS["Derm"]
        if model:
            try:
                tensor = preprocess_image(image_data)
                result = vision_predict(model, device, tensor, classes)
                result["model"] = "Derm Foundation (EfficientNet-B0)"
                return jsonify({"success": True, **result})
            except Exception as e:
                return jsonify({"success": False, "error": str(e)}), 500

    return jsonify({"success": True, "model": "Derm Foundation (EfficientNet-B0)",
                    "prediction": "Status: model loading", "confidence": 0.0,
                    "probabilities": {c: 0.0 for c in classes}})


@app.route("/api/multimodel/analyze", methods=["POST"])
def multimodel_analyze():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    data = request.json or {}
    query = data.get("query", data.get("prompt", ""))
    image_data = data.get("image", "")
    image_type = data.get("image_type", "cxr")

    # Run both vision + text analysis
    responses = {}

    if image_data:
        resp = app.test_client().post(
            "/api/medgemma/analyze-image",
            json={"image": image_data, "image_type": image_type, "query": query},
            headers={"Authorization": f"Bearer {AUTH_TOKEN}"}
        )
        if resp.status_code == 200:
            responses["image_analysis"] = resp.get_json()

    if query:
        text_response = medgemma_generate(query)
        responses["text_analysis"] = text_response

    return jsonify({
        "success": True,
        "model": "QubitPage MultiModel (MedGemma + Foundation Models)",
        "query": query,
        "responses": responses,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
    })


# ─── Startup ──────────────────────────────────────────────────────────────────

def startup():
    """Load all models based on PORT/MODEL_TYPE."""
    global MODEL_LOADED

    log.info(f"Starting server on port {PORT}, model type: {MODEL_TYPE}")

    load_txgemma_results()

    # Vision model configs
    VISION_CONFIG = {
        "CXR": ("densenet121", "/workspace/models/cxr_foundation.pth", 5),
        "Path": ("vit_b_16", "/workspace/models/path_foundation.pth", 4),
        "BrainMRI": ("resnet50", "/workspace/models/brain_mri.pth", 4),
        "Derm": ("efficientnet_b0", "/workspace/models/derm_foundation.pth", 5),
    }

    if MODEL_TYPE in ("medgemma", "multimodel"):
        # Load MedGemma (heaviest — do this on ports 5051, 5055)
        import threading
        t = threading.Thread(target=load_medgemma, daemon=True)
        t.start()

    if MODEL_TYPE in ("cxr",):
        model, device = load_vision_model("CXR", "densenet121",
                                          "/workspace/models/cxr_foundation.pth", 5)
        VISION_MODELS["CXR"] = (model, device)
        MODEL_LOADED = True

    elif MODEL_TYPE in ("multimodel", "path"):
        for name, (arch, path, n_cls) in VISION_CONFIG.items():
            model, device = load_vision_model(name, arch, path, n_cls)
            VISION_MODELS[name] = (model, device)
        MODEL_LOADED = True

    elif MODEL_TYPE in ("hear", "derm"):
        model, device = load_vision_model("Derm", "efficientnet_b0",
                                          "/workspace/models/derm_foundation.pth", 5)
        VISION_MODELS["Derm"] = (model, device)
        MODEL_LOADED = True

    elif MODEL_TYPE == "txgemma":
        MODEL_LOADED = True  # Already loaded results above

    log.info(f"Server ready (models loading in background if applicable)")


if __name__ == "__main__":
    startup()
    log.info(f"Server running on 0.0.0.0:{PORT}")
    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)
