#!/usr/bin/env python3
"""
Fixed MedGemma LoRA fine-tuning script.
Fixes applied:
 1. attn_implementation="eager" (bypass torch>=2.6 sliding window mask)
 2. token_type_ids=zeros (Gemma3 requires them during training)
 3. gradient_checkpointing=True + batch_size=1 + max_length=256 (reduce VRAM)
 4. PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
"""
import os, time, random, logging, json
from pathlib import Path

os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(levelname)s %(message)s")
log = logging.getLogger(__name__)

HF_TOKEN = os.environ.get("HF_TOKEN", "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")
LORA_DIR = "/workspace/models/medgemma_lora"
MODEL_ID = "google/medgemma-4b-it"

os.environ["HF_TOKEN"] = HF_TOKEN
os.environ["HUGGING_FACE_HUB_TOKEN"] = HF_TOKEN

MEDICAL_QA = [
    {"q": "What causes glioblastoma multiforme (GBM)?", "a": "GBM arises from astrocytes via EGFR, PTEN, TP53, and IDH mutations. Standard of care: temozolomide + radiation (Stupp protocol). Median OS: 15 months."},
    {"q": "How does temozolomide work against GBM?", "a": "Temozolomide methylates DNA at N7 and O6 guanine causing double-strand breaks. MGMT methylation predicts response — methylated tumors have 2x better survival."},
    {"q": "What BBB strategies improve GBM drug delivery?", "a": "Focused ultrasound (FUS), lipid nanoparticles, convection-enhanced delivery (CED). BBB penetration: MW <400 Da, PSA <90, LogP 2-4."},
    {"q": "What defines MDR-TB?", "a": "MDR-TB: resistance to isoniazid AND rifampicin. XDR-TB also resists fluoroquinolones and bedaquiline/linezolid. WHO 2022: 450,000 new cases globally."},
    {"q": "How does bedaquiline work against TB?", "a": "Bedaquiline inhibits mycobacterial ATP synthase subunit c, blocking oxidative phosphorylation. Half-life: 5.5 months. Used in BPaL regimens."},
    {"q": "Why is PDAC so lethal?", "a": "5-year survival 12%: late diagnosis, desmoplastic stroma blocks drugs, KRAS mutation in 95%, chemo-resistance via ABC transporters."},
    {"q": "What KRAS G12D inhibitors exist for PDAC?", "a": "MRTX1133 (IC50=0.18 nM) shows 70% regression in mouse models. Pan-KRAS inhibitors and SOS1 inhibitors in clinical trials."},
    {"q": "What drives ALS neurodegeneration?", "a": "TDP-43/FUS aggregation, SOD1 misfolding, C9ORF72 hexanucleotide repeats, glutamate excitotoxicity, mitochondrial dysfunction."},
    {"q": "How does riluzole slow ALS?", "a": "Riluzole inhibits glutamate release and blocks voltage-gated Na channels, reducing excitotoxicity. Extends survival 2-3 months. Combined with edaravone."},
    {"q": "What drives idiopathic pulmonary fibrosis?", "a": "AECII cell apoptosis, TGF-beta1 activating myofibroblasts, ECM deposition, TERT/TERC mutations, MUC5B variant rs35705950."},
    {"q": "How do pirfenidone and nintedanib treat IPF?", "a": "Pirfenidone: TGF-beta inhibition, reduces FVC decline 50%. Nintedanib: PDGFR/VEGFR/FGFR kinase inhibitor. Both slow fibrosis progression."},
    {"q": "What defines TNBC?", "a": "No ER, PR, HER2. Standard: anthracycline/taxane chemo. BRCA-mutated: PARP inhibitors. PD-L1+: pembrolizumab. 5-year metastatic survival: 12%."},
    {"q": "What novel targets exist for TNBC?", "a": "TROP-2 (sacituzumab govitecan), AKT1/PIK3CA (ipatasertib), PARP (olaparib), PD-L1 (pembrolizumab), AR (enzalutamide), VEGFR, Wnt/beta-catenin."},
    {"q": "Explain the amyloid cascade hypothesis in Alzheimer's.", "a": "APP cleavage produces Abeta42 monomers → oligomers → plaques. Oligomers disrupt synapses and trigger tau hyperphosphorylation and NFT formation."},
    {"q": "How do lecanemab and donanemab work?", "a": "Lecanemab: targets Abeta protofibrils, 27% cognitive decline reduction. Donanemab: targets N3pG pyroglutamate Abeta, 35% reduction. Both cause ARIA."},
    {"q": "Analyze: bilateral lower lobe consolidation with air bronchograms.", "a": "Indicates lobar pneumonia or ARDS. Differential: S. pneumoniae, Klebsiella, COVID-19, aspiration. Treatment: beta-lactam + macrolide."},
    {"q": "What quantum approaches accelerate drug discovery?", "a": "VQE for molecular energy, QAOA for compound optimization, quantum Boltzmann machines for generation, HHL for QSAR, quantum annealing for pharmacophore matching."},
    {"q": "Explain ADMET properties in drug development.", "a": "Absorption (Lipinski Rule of 5), Distribution (BBB, PPB), Metabolism (CYP3A4), Excretion (renal/hepatic), Toxicity (hERG, AMES, DILI). Over 40% of drug failures are ADMET-related."},
    {"q": "How does MedGemma assist clinical decision support?", "a": "Medical report analysis, differential diagnosis, imaging interpretation, drug interaction checking, guideline-based recommendations. 82.6% on MedQA (USMLE-style)."},
    {"q": "What are key oncology biomarkers?", "a": "CEA (colorectal), PSA (prostate), CA-125 (ovarian), HER2/BRCA (breast), EGFR/ALK/PD-L1 (lung), BCR-ABL (CML), AFP (hepatocellular), KRAS/BRAF. ctDNA liquid biopsy enables monitoring."},
]

import torch
log.info(f"PyTorch {torch.__version__} | CUDA: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    free = (torch.cuda.get_device_properties(0).total_memory - torch.cuda.memory_allocated(0)) / 1e9
    log.info(f"GPU: {torch.cuda.get_device_name(0)} | VRAM free: {free:.1f} GB")

from transformers import (
    AutoTokenizer, AutoModelForCausalLM,
    TrainingArguments, Trainer, DataCollatorForLanguageModeling,
    BitsAndBytesConfig
)
from peft import LoraConfig, get_peft_model, TaskType, prepare_model_for_kbit_training
from datasets import Dataset

os.makedirs(LORA_DIR, exist_ok=True)

log.info(f"Loading tokenizer from {MODEL_ID}...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, token=HF_TOKEN, trust_remote_code=True)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "right"

log.info("Loading model in 4-bit with gradient checkpointing...")
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_use_double_quant=True,
)
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID, token=HF_TOKEN,
    quantization_config=bnb_config,
    device_map="auto",
    trust_remote_code=True,
    torch_dtype=torch.bfloat16,
    attn_implementation="eager",
)
model.config.use_cache = False

# Enable gradient checkpointing to save VRAM
model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=True)
log.info("Base model loaded with gradient checkpointing enabled.")

lora_config = LoraConfig(
    r=8,           # reduced from 16 to save VRAM
    lora_alpha=16,
    target_modules=["q_proj", "v_proj"],  # only q+v to save VRAM (most impactful)
    lora_dropout=0.05,
    bias="none",
    task_type=TaskType.CAUSAL_LM,
)
model = get_peft_model(model, lora_config)
model.print_trainable_parameters()

def format_example(item):
    return f"<start_of_turn>user\n{item['q']}<end_of_turn>\n<start_of_turn>model\n{item['a']}<end_of_turn>"

texts = [format_example(ex) for ex in MEDICAL_QA] * 3
random.shuffle(texts)

def tokenize(batch):
    enc = tokenizer(
        batch["text"],
        truncation=True,
        max_length=256,   # reduced from 512 to save VRAM
        padding="max_length",
    )
    enc["labels"] = enc["input_ids"].copy()
    if "token_type_ids" not in enc:
        enc["token_type_ids"] = [[0] * len(ids) for ids in enc["input_ids"]]
    return enc

ds = Dataset.from_dict({"text": texts})
ds = ds.map(tokenize, batched=True, remove_columns=["text"])
log.info(f"Dataset: {len(ds)} samples | columns: {ds.column_names}")

training_args = TrainingArguments(
    output_dir=LORA_DIR,
    num_train_epochs=3,
    per_device_train_batch_size=1,    # reduced from 2
    gradient_accumulation_steps=8,   # increased to compensate
    learning_rate=2e-4,
    bf16=torch.cuda.is_available(),
    logging_steps=5,
    save_strategy="epoch",
    save_total_limit=1,
    warmup_ratio=0.05,
    lr_scheduler_type="cosine",
    report_to="none",
    dataloader_pin_memory=False,
    remove_unused_columns=False,
    gradient_checkpointing=True,
    optim="paged_adamw_8bit",  # 8-bit optimizer saves ~3GB
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=ds,
    data_collator=DataCollatorForLanguageModeling(tokenizer, mlm=False),
)

log.info("Starting MedGemma LoRA training...")
t0 = time.time()
train_result = trainer.train()
elapsed = time.time() - t0
log.info(f"Training done in {elapsed/60:.1f} min | loss={train_result.training_loss:.4f}")

model.save_pretrained(LORA_DIR)
tokenizer.save_pretrained(LORA_DIR)
log.info(f"LoRA adapter saved to {LORA_DIR}")

size_mb = sum(f.stat().st_size for f in Path(LORA_DIR).rglob("*") if f.is_file()) / 1e6
log.info(f"LoRA adapter size: {size_mb:.1f} MB")

manifest_path = "/workspace/models/manifest.json"
if Path(manifest_path).exists():
    with open(manifest_path) as f:
        manifest = json.load(f)
    manifest["models"]["medgemma_lora"]["status"] = "completed"
    manifest["results"]["medgemma_lora"] = {
        "status": "completed",
        "size_mb": size_mb,
        "train_loss": train_result.training_loss,
        "elapsed_min": elapsed / 60,
    }
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)
    log.info("Manifest updated.")

log.info("ALL DONE — restart servers to load LoRA weights.")
